import './bootstrap';
import 'remixicon/fonts/remixicon.css'

