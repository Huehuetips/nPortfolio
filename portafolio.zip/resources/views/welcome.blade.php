<x-app-layout>
<x-portfolio.index>
</x-portfolio.index>
</x-app-layout>