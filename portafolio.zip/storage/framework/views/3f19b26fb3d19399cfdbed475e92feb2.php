<div>
    <?php echo e($isDarkMode); ?>

    <button wire:click="toggleTheme" id="theme-toggle" class="z-50 fixed right-6 md:bottom-10 bottom-10 rounded-full size-14 text-2xl bg-black dark:bg-white text-white dark:text-black ">
        <!--[if BLOCK]><![endif]--><?php if($darkMode): ?>
            <i class="ri-sun-line text-5xl"></i>
        <?php else: ?>
            <i class="ri-moon-line text-5xl"></i>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </button>
</div>

<script>
    const darkMode = <?php echo json_encode(session('darkMode', false), 512) ?>;

    if (darkMode) {
        document.body.classList.add('dark');
    } else {
        document.body.classList.remove('dark');
    }
    const themeToggleBtn = document.getElementById('theme-toggle');

    themeToggleBtn.addEventListener('click', function () {
        // Cambia el estado del tema en el frontend
        document.body.classList.toggle('dark');
    });
</script>
<?php /**PATH C:\xampp\htdocs\laravel\portafolio\resources\views/livewire/theme-switcher.blade.php ENDPATH**/ ?>