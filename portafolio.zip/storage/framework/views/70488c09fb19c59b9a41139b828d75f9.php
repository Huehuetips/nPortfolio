<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>

<?php if (isset($component)) { $__componentOriginal8daa113801f6a191eb1520452fe5c6be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8daa113801f6a191eb1520452fe5c6be = $attributes; } ?>
<?php $component = App\View\Components\Portfolio\Contact::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portfolio.contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Portfolio\Contact::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8daa113801f6a191eb1520452fe5c6be)): ?>
<?php $attributes = $__attributesOriginal8daa113801f6a191eb1520452fe5c6be; ?>
<?php unset($__attributesOriginal8daa113801f6a191eb1520452fe5c6be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8daa113801f6a191eb1520452fe5c6be)): ?>
<?php $component = $__componentOriginal8daa113801f6a191eb1520452fe5c6be; ?>
<?php unset($__componentOriginal8daa113801f6a191eb1520452fe5c6be); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\portafolio\storage\framework\views/d2370e6ddf88fb22b269f302060d4b9c.blade.php ENDPATH**/ ?>