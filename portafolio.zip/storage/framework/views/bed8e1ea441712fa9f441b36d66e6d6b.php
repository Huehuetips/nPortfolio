<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        
        <!-- Styles -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="antialiased font-sans no-drag">
        <div class="transition-all duration-200 ease-in-out bg-gray-200 text-black/90 dark:bg-zinc-800 dark:text-white/50">
            <div class="md:p-3 selection:bg-[#5f5ea0] dark:selection:bg-[#444444] selection:text-white">
                <div class="">
                    <header class="grid grid-cols-2 items-center gap-2 p-3 lg:grid-cols-3">
                        <div class="flex lg:justify-center lg:col-start-2">
                            
                        </div>
                        <?php if(Route::has('login')): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('welcome.navigation', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1720779191-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        <?php endif; ?>
                    </header>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('theme-switcher');

$__html = app('livewire')->mount($__name, $__params, 'lw-1720779191-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <main class="min-h-screen">
                        <?php echo e($slot); ?>

                    </main>
                    <footer class="py-16 text-center text-sm text-black dark:text-white/70">
                        Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?> (PHP v<?php echo e(PHP_VERSION); ?>)
                    </footer>
                </div>
            </div>
        </div>
    </body>
</html>

<?php /**PATH C:\xampp\htdocs\laravel\portafolio\resources\views/layouts/app.blade.php ENDPATH**/ ?>