<div class="h-full">
    <div class="flex border-b gap-x-3 justify-center flex-wrap">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button wire:click="setActiveTab(<?php echo e($index); ?>)" 
                    class="py-2 px-4 rounded-t-lg <?php echo e($activeTab === $index ? 'bg-white border-l border-t border-r text-blue-700' : 'bg-gray-200 text-gray-700'); ?>">
                <?php echo e($tab['title']); ?>

            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <div class="h-[calc(100%-3rem)] p-8 bg-zinc-100 dark:bg-neutral-800">
        <!--[if BLOCK]><![endif]--><?php if(isset($tabs[$activeTab]['component'])): ?>
            <!--[if BLOCK]><![endif]--><?php if(str_starts_with($tabs[$activeTab]['component'], 'x-')): ?>
                <?php
                    $componentName = str_replace('x-', '', $tabs[$activeTab]['component']);
                ?>
                <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $componentName] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
            <?php else: ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split($tabs[$activeTab]['component'], $tabs[$activeTab]['params'] ?? []);

$__html = app('livewire')->mount($__name, $__params, $activeTab, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php else: ?>
            <?php echo $tabs[$activeTab]['content'] ?? ''; ?>

        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel\portafolio\resources\views/livewire/portfolio/contents.blade.php ENDPATH**/ ?>